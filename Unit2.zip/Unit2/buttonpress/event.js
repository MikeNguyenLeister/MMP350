// my button JavaScript file
submit.onclick=function(event){
console.log(this);
console.log(event);
console.log("you clicked me!");
}